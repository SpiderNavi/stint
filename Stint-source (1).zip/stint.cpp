// Stint — a tiny floating focus timer for Windows.
// Single-file Win32 + GDI+ app. Build with MinGW-w64 (see build.sh).
//
// Concepts
//   Session : the whole plan you start (e.g. 4 rounds).
//   Round   : one Focus block, followed by a Break block (none after the last round).
//   Block   : a single Focus / Break / Long break segment shown in the bar.
//   Extra   : time you keep going after a block's timer hits zero (the stopwatch).

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <algorithm>
using std::min;
using std::max;
#include <gdiplus.h>
#include <string>
#include <vector>
#include <cmath>
#include <cstdio>
#include <cwchar>

using namespace Gdiplus;

// ---------------------------------------------------------------- constants
static const wchar_t* kClass = L"StintFloatingTimer";
static const wchar_t* kTitle = L"Stint";
static const float SH = 18.f;            // shadow margin (logical px)
static const UINT WM_TRAY = WM_APP + 1;
enum { T_TICK = 1, T_ANIM = 2, T_REPEAT = 3, T_TOPMOST = 4 };
enum { K_FOCUS = 0, K_BREAK = 1, K_LONG = 2 };
enum View { V_MAIN, V_COMPACT, V_SETUP };

enum {
    Z_NONE = 0, Z_MAIN, Z_SKIP, Z_RESET, Z_SETUP, Z_COMPACT, Z_CLOSE,
    Z_DEC0 = 20, Z_INC0 = 30, Z_TOG0 = 40, Z_CANCEL = 50, Z_START
};
enum {
    M_TOGGLE = 100, M_DONE, M_SKIP, M_RESET, M_SETUP, M_COMPACT, M_TOP, M_WINFOCUS, M_SHOWHIDE, M_EXIT
};

// ---------------------------------------------------------------- palette
namespace P {
    const Color text(255, 255, 255, 255);
    const Color sub(255, 0x8C, 0x94, 0xA6);
    const Color dim(255, 0x6F, 0x78, 0x8C);
    const Color soft(255, 0xD5, 0xDA, 0xE4);
    const Color blue(255, 0x2D, 0x8C, 0xFF);
    const Color blueText(255, 0x5A, 0xA8, 0xFF);
    const Color circle(255, 0x1C, 0x3A, 0x6B);
    const Color circleHot(255, 0x25, 0x48, 0x82);
    const Color circleIcon(255, 0x3D, 0x8B, 0xFF);
    const Color chip(255, 0x1C, 0x26, 0x38);
    const Color chipHot(255, 0x27, 0x33, 0x4A);
}

// ---------------------------------------------------------------- data
struct Cfg {
    int focus = 20, brk = 5, rounds = 4, longBrk = 15, longEvery = 0;
    bool autoCont = false, winFocus = true;
};
struct Block {
    int kind; int round;
    long long dur; long long elapsed;
    bool alerted; bool done;
};
struct Zone { int id; RectF r; };

struct App {
    HWND hwnd = nullptr;
    HINSTANCE inst = nullptr;
    float scale = 1.f;
    View view = V_MAIN;
    View backView = V_MAIN;
    bool prefCompact = false;
    bool topmost = true;
    bool hidden = false;

    Cfg cfg, edit;
    std::vector<Block> blocks;
    int idx = 0;
    bool running = false;
    bool started = false;
    unsigned long long lastTick = 0;

    // ui
    std::vector<Zone> zones;
    int hover = Z_NONE, pressed = Z_NONE;
    bool inside = false, tracking = false;
    bool dragging = false, dragMoved = false;
    POINT dragStart{}, winStart{};
    unsigned long long blinkStart = 0;
    bool blinking = false;
    int repeatZone = Z_NONE; int repeatCount = 0;
    long long lastShownSec = -1;

    NOTIFYICONDATAW nid{};
    UINT taskbarCreated = 0;
    std::wstring iniPath;

    FontFamily* fBold = nullptr;   // big numbers
    FontFamily* fSemi = nullptr;   // labels
    FontFamily* fReg = nullptr;    // body
    bool semiIsBold = false;       // fSemi fell back to bold style
    bool embeddedFonts = false;    // using the embedded Inter weights
} A;

// ---------------------------------------------------------------- helpers
static unsigned long long Now() { return GetTickCount64(); }

static std::wstring Clock(long long ms, bool ceilSecs) {
    if (ms < 0) ms = 0;
    long long s = ceilSecs ? (ms + 999) / 1000 : ms / 1000;
    long long h = s / 3600, m = (s / 60) % 60, sec = s % 60;
    wchar_t b[32];
    if (h > 0) swprintf(b, 32, L"%lld:%02lld:%02lld", h, m, sec);
    else swprintf(b, 32, L"%02lld:%02lld", m, sec);
    return b;
}
// stats row: no leading zero on minutes (0:42, 12:05, 1:02:03)
static std::wstring StatClock(long long ms) {
    std::wstring c = Clock(ms, false);
    if (c.size() == 5 && c[0] == L'0') c.erase(0, 1);
    return c;
}
static std::wstring ShortDur(long long minutes) {
    wchar_t b[32];
    if (minutes >= 60) {
        if (minutes % 60) swprintf(b, 32, L"%lldh %lldm", minutes / 60, minutes % 60);
        else swprintf(b, 32, L"%lldh", minutes / 60);
    } else swprintf(b, 32, L"%lld min", minutes);
    return b;
}

static void RR(GraphicsPath& p, float x, float y, float w, float h, float r) {
    r = min(r, min(w, h) / 2.f);
    if (r < 0.5f) { p.AddRectangle(RectF(x, y, w, h)); return; }
    float d = r * 2;
    p.AddArc(x, y, d, d, 180, 90);
    p.AddArc(x + w - d, y, d, d, 270, 90);
    p.AddArc(x + w - d, y + h - d, d, d, 0, 90);
    p.AddArc(x, y + h - d, d, d, 90, 90);
    p.CloseFigure();
}
static void FillRR(Graphics& g, const Brush& b, float x, float y, float w, float h, float r) {
    GraphicsPath p; RR(p, x, y, w, h, r); g.FillPath(&b, &p);
}
static void StrokeRR(Graphics& g, const Pen& pen, float x, float y, float w, float h, float r) {
    GraphicsPath p; RR(p, x, y, w, h, r); g.DrawPath(&pen, &p);
}
static Color WithA(const Color& c, BYTE a) { return Color(a, c.GetR(), c.GetG(), c.GetB()); }
static Color Hex(UINT rgb, BYTE a = 255) { return Color(a, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }

// ---- text (drawn as paths: crisp, alpha-correct on a layered window)
enum { AL_L, AL_C, AL_R };
static FontFamily* Fam(int which) { return which == 0 ? A.fBold : which == 1 ? A.fSemi : A.fReg; }
static int StyleFor(int which) {
    if (A.embeddedFonts) return FontStyleRegular;  // each Inter weight is its own family
    if (which == 0) return FontStyleBold;
    if (which == 1) return A.semiIsBold ? FontStyleBold : FontStyleRegular;
    return FontStyleRegular;
}
static void BuildText(GraphicsPath& p, const std::wstring& s, int which, float size, float x, float baseline) {
    FontFamily* f = Fam(which);
    int st = StyleFor(which);
    float asc = size * f->GetCellAscent(st) / (float)f->GetEmHeight(st);
    StringFormat fmt(StringFormat::GenericTypographic());
    fmt.SetFormatFlags(fmt.GetFormatFlags() | StringFormatFlagsMeasureTrailingSpaces | StringFormatFlagsNoWrap);
    p.AddString(s.c_str(), -1, f, st, size, PointF(x, baseline - asc), &fmt);
}
static float TextW(const std::wstring& s, int which, float size) {
    if (s.empty()) return 0;
    GraphicsPath p; BuildText(p, s, which, size, 0, 0);
    RectF b; p.GetBounds(&b);
    return b.X + b.Width;
}
// returns drawn width
static float Text(Graphics& g, const std::wstring& s, int which, float size, float x, float baseline,
                  const Color& c, int align = AL_L) {
    if (s.empty()) return 0;
    float w = TextW(s, which, size);
    if (align == AL_C) x -= w / 2; else if (align == AL_R) x -= w;
    GraphicsPath p; BuildText(p, s, which, size, x, baseline);
    SolidBrush b(c); g.FillPath(&b, &p);
    return w;
}

// ---------------------------------------------------------------- settings
static int IniInt(const wchar_t* k, int def) { return GetPrivateProfileIntW(L"stint", k, def, A.iniPath.c_str()); }
static void IniPut(const wchar_t* k, int v) {
    wchar_t b[32]; swprintf(b, 32, L"%d", v);
    WritePrivateProfileStringW(L"stint", k, b, A.iniPath.c_str());
}
static void LoadSettings() {
    wchar_t dir[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_APPDATA, nullptr, 0, dir))) {
        std::wstring d = std::wstring(dir) + L"\\Stint";
        CreateDirectoryW(d.c_str(), nullptr);
        A.iniPath = d + L"\\stint.ini";
    } else A.iniPath = L"stint.ini";
    Cfg& c = A.cfg;
    c.focus = std::clamp(IniInt(L"focus", 20), 1, 180);
    c.brk = std::clamp(IniInt(L"break", 5), 1, 60);
    c.rounds = std::clamp(IniInt(L"rounds", 4), 1, 12);
    c.longBrk = std::clamp(IniInt(L"longBreak", 15), 1, 90);
    c.longEvery = std::clamp(IniInt(L"longEvery", 0), 0, 12);
    c.autoCont = IniInt(L"autoContinue", 0) != 0;
    c.winFocus = IniInt(L"openWindowsFocus", 1) != 0;
    A.topmost = IniInt(L"topmost", 1) != 0;
    A.prefCompact = IniInt(L"compact", 0) != 0;
}
static void SaveSettings() {
    Cfg& c = A.cfg;
    IniPut(L"focus", c.focus); IniPut(L"break", c.brk); IniPut(L"rounds", c.rounds);
    IniPut(L"longBreak", c.longBrk); IniPut(L"longEvery", c.longEvery);
    IniPut(L"autoContinue", c.autoCont); IniPut(L"openWindowsFocus", c.winFocus);
    IniPut(L"topmost", A.topmost); IniPut(L"compact", A.prefCompact);
    if (A.hwnd) {
        RECT r; GetWindowRect(A.hwnd, &r);
        IniPut(L"x", r.left); IniPut(L"y", r.top); IniPut(L"hasPos", 1);
    }
}

// ---------------------------------------------------------------- session logic
static std::vector<Block> BuildPlan(const Cfg& c) {
    std::vector<Block> v;
    for (int r = 1; r <= c.rounds; r++) {
        v.push_back({K_FOCUS, r, c.focus * 60000LL, 0, false, false});
        if (r < c.rounds) {
            bool lng = c.longEvery > 0 && r % c.longEvery == 0;
            v.push_back({lng ? K_LONG : K_BREAK, r, (lng ? c.longBrk : c.brk) * 60000LL, 0, false, false});
        }
    }
    return v;
}
static bool Complete() { return A.idx >= (int)A.blocks.size(); }
static Block* Cur() { return Complete() ? nullptr : &A.blocks[A.idx]; }
static bool Over() { Block* b = Cur(); return b && b->elapsed >= b->dur; }
static long long FocusedMs() {
    long long t = 0;
    for (int i = 0; i < (int)A.blocks.size() && i <= A.idx; i++)
        if (A.blocks[i].kind == K_FOCUS) t += A.blocks[i].elapsed;
    return t;
}
static long long ExtraMs() {
    long long t = 0;
    for (int i = 0; i < (int)A.blocks.size() && i <= A.idx; i++)
        if (A.blocks[i].kind == K_FOCUS) t += max(0LL, A.blocks[i].elapsed - A.blocks[i].dur);
    return t;
}
static int RoundsDone() {
    int n = 0;
    for (auto& b : A.blocks) if (b.kind == K_FOCUS && b.done) n++;
    return n;
}

static void Render();
static void UpdateTray();

static void OpenWindowsFocus() {
    HINSTANCE r = ShellExecuteW(nullptr, L"open", L"ms-settings:quiethours", nullptr, nullptr, SW_SHOWNORMAL);
    if ((INT_PTR)r <= 32) ShellExecuteW(nullptr, L"open", L"ms-clock:", nullptr, nullptr, SW_SHOWNORMAL);
}

static void StartBlink() {
    A.blinking = true; A.blinkStart = Now();
    SetTimer(A.hwnd, T_ANIM, 16, nullptr);
}

static void ResetSession(bool run) {
    A.blocks = BuildPlan(A.cfg);
    A.idx = 0; A.running = false; A.started = false;
    A.lastTick = Now();
    if (run) {
        A.running = true; A.started = true;
        if (A.cfg.winFocus) OpenWindowsFocus();
    }
}
static void SetRunning(bool on) {
    if (Complete()) return;
    if (on && !A.started) {
        A.started = true;
        if (A.cfg.winFocus) OpenWindowsFocus();
    }
    A.running = on; A.lastTick = Now();
}
static void Advance() {
    if (Complete()) return;
    A.blocks[A.idx].done = true;
    A.idx++;
    A.started = true;
    if (Complete()) A.running = false;
    A.lastTick = Now();
}

static void Tick() {
    unsigned long long n = Now();
    long long d = (long long)(n - A.lastTick);
    A.lastTick = n;
    if (!A.running || Complete()) return;
    Block& b = A.blocks[A.idx];
    b.elapsed += d;
    if (b.elapsed >= b.dur && !b.alerted) {
        b.alerted = true;
        StartBlink();
        if (A.cfg.autoCont) {
            long long spill = b.elapsed - b.dur;
            b.elapsed = b.dur;
            Advance();
            if (!Complete()) { A.running = true; A.blocks[A.idx].elapsed = spill; }
        }
    }
}

// ---------------------------------------------------------------- icons
static void Icon(Graphics& g, int kind, float cx, float cy, float s, const Color& c) {
    // s = icon box size (logical px)
    Pen pen(c, max(1.5f, s * 0.13f));
    pen.SetStartCap(LineCapRound); pen.SetEndCap(LineCapRound); pen.SetLineJoin(LineJoinRound);
    SolidBrush br(c);
    float h = s / 2;
    switch (kind) {
    case 0: { // play
        GraphicsPath p; PointF pts[3] = {{cx - h * 0.55f, cy - h * 0.8f}, {cx + h * 0.85f, cy}, {cx - h * 0.55f, cy + h * 0.8f}};
        p.AddPolygon(pts, 3); Pen j(c, s * 0.12f); j.SetLineJoin(LineJoinRound);
        g.FillPath(&br, &p); g.DrawPath(&j, &p); break; }
    case 1: { // pause
        float w = s * 0.2f, hh = s * 0.8f;
        FillRR(g, br, cx - s * 0.3f, cy - hh / 2, w, hh, w / 2);
        FillRR(g, br, cx + s * 0.1f, cy - hh / 2, w, hh, w / 2); break; }
    case 2: { // check
        PointF pts[3] = {{cx - h * 0.75f, cy + h * 0.02f}, {cx - h * 0.2f, cy + h * 0.58f}, {cx + h * 0.8f, cy - h * 0.6f}};
        Pen p2(c, s * 0.15f); p2.SetStartCap(LineCapRound); p2.SetEndCap(LineCapRound); p2.SetLineJoin(LineJoinRound);
        g.DrawLines(&p2, pts, 3); break; }
    case 3: case 6: { // restart / reset (circular arrow)
        float r = h * 0.72f;
        g.DrawArc(&pen, cx - r, cy - r, 2 * r, 2 * r, -60, 300);
        float a = -60.f * 3.14159265f / 180.f;
        PointF tip(cx + r * cosf(a), cy + r * sinf(a));
        PointF pts[3] = {{tip.X - h * 0.45f, tip.Y - h * 0.08f}, tip, {tip.X - h * 0.05f, tip.Y + h * 0.45f}};
        g.DrawLines(&pen, pts, 3); break; }
    case 4: { // skip next
        GraphicsPath p; PointF pts[3] = {{cx - h * 0.7f, cy - h * 0.7f}, {cx + h * 0.35f, cy}, {cx - h * 0.7f, cy + h * 0.7f}};
        p.AddPolygon(pts, 3); g.FillPath(&br, &p);
        g.DrawLine(&pen, cx + h * 0.65f, cy - h * 0.7f, cx + h * 0.65f, cy + h * 0.7f); break; }
    case 5: { // sliders (setup)
        g.DrawLine(&pen, cx - h * 0.8f, cy - h * 0.4f, cx + h * 0.8f, cy - h * 0.4f);
        g.DrawLine(&pen, cx - h * 0.8f, cy + h * 0.4f, cx + h * 0.8f, cy + h * 0.4f);
        float k = s * 0.16f;
        SolidBrush bk(c);
        g.FillEllipse(&bk, cx + h * 0.3f - k, cy - h * 0.4f - k, 2 * k, 2 * k);
        g.FillEllipse(&bk, cx - h * 0.3f - k, cy + h * 0.4f - k, 2 * k, 2 * k); break; }
    case 7: { // compact (shrink): two inward corners
        float o = h * 0.75f, i = h * 0.15f;
        PointF a1[3] = {{cx - o, cy - i * 2.2f}, {cx - i, cy - i}, {cx - i * 2.2f, cy - o}};
        PointF a2[3] = {{cx + o, cy + i * 2.2f}, {cx + i, cy + i}, {cx + i * 2.2f, cy + o}};
        g.DrawLines(&pen, a1, 3); g.DrawLines(&pen, a2, 3); break; }
    case 8: { // close
        float o = h * 0.6f;
        g.DrawLine(&pen, cx - o, cy - o, cx + o, cy + o);
        g.DrawLine(&pen, cx - o, cy + o, cx + o, cy - o); break; }
    case 9: { // expand: two outward corners
        float o = h * 0.75f, k = h * 0.55f;
        PointF a1[3] = {{cx - o, cy - o + k}, {cx - o, cy - o}, {cx - o + k, cy - o}};
        PointF a2[3] = {{cx + o, cy + o - k}, {cx + o, cy + o}, {cx + o - k, cy + o}};
        g.DrawLines(&pen, a1, 3); g.DrawLines(&pen, a2, 3);
        g.DrawLine(&pen, cx - o, cy - o, cx - h * 0.1f, cy - h * 0.1f);
        g.DrawLine(&pen, cx + o, cy + o, cx + h * 0.1f, cy + h * 0.1f); break; }
    case 10: { // minus
        g.DrawLine(&pen, cx - h * 0.55f, cy, cx + h * 0.55f, cy); break; }
    case 11: { // plus
        g.DrawLine(&pen, cx - h * 0.55f, cy, cx + h * 0.55f, cy);
        g.DrawLine(&pen, cx, cy - h * 0.55f, cx, cy + h * 0.55f); break; }
    }
}

// ---------------------------------------------------------------- drawing
static void AddZone(int id, float x, float y, float w, float h) { A.zones.push_back({id, RectF(x, y, w, h)}); }

static void DrawCard(Graphics& g, float w, float h, float r) {
    for (int i = 9; i >= 1; i--) {
        float e = i * 1.7f;
        SolidBrush b(Color(9, 0, 0, 0));
        FillRR(g, b, -e, -e + 5, w + 2 * e, h + 2 * e, r + e);
    }
    GraphicsPath p; RR(p, 0, 0, w, h, r);
    LinearGradientBrush lg(PointF(0, -1), PointF(0, h + 1), Hex(0x1E2537), Hex(0x10141D));
    Color stops[3] = {Hex(0x1E2537), Hex(0x161B27), Hex(0x10141D)};
    REAL pos[3] = {0.f, 0.45f, 1.f};
    lg.SetInterpolationColors(stops, pos, 3);
    g.FillPath(&lg, &p);
    Pen bp(Color(30, 255, 255, 255), 1.f);
    StrokeRR(g, bp, 0.5f, 0.5f, w - 1, h - 1, r - 0.5f);
}

static void DrawBlink(Graphics& g, float w, float h, float r) {
    if (!A.blinking) return;
    float t = (float)(Now() - A.blinkStart);
    // two pulses: 0-380ms and 560-940ms
    float a = 0;
    if (t < 380) a = sinf(3.14159f * t / 380.f);
    else if (t >= 560 && t < 940) a = sinf(3.14159f * (t - 560) / 380.f);
    if (a <= 0) return;
    SolidBrush ov(Color((BYTE)(150 * a), 0x2D, 0x8C, 0xFF));
    FillRR(g, ov, 0, 0, w, h, r);
    Pen gp(Color((BYTE)(230 * a), 255, 255, 255), 2.f);
    StrokeRR(g, gp, 1, 1, w - 2, h - 2, r - 1);
}

struct SegColors { Color fill, border; };
static SegColors SegFuture(int k) { return k == K_FOCUS ? SegColors{Hex(0x163A73), Hex(0x24539F)} : SegColors{Hex(0x12384A), Hex(0x1F5E75)}; }
static SegColors SegDone(int k) { return k == K_FOCUS ? SegColors{Hex(0x1F56AE), Hex(0x2C68C9)} : SegColors{Hex(0x1A6A86), Hex(0x2687A6)}; }

// Lays out segments across [x, x+w]; returns x positions & widths
static void LayoutSegs(const std::vector<Block>& v, float x, float w, float gap, std::vector<float>& xs, std::vector<float>& ws) {
    int n = (int)v.size();
    xs.assign(n, 0); ws.assign(n, 0);
    if (!n) return;
    float avail = w - gap * (n - 1);
    float minW = max(3.f, min(9.f, avail / n * 0.6f));
    double tot = 0; for (auto& b : v) tot += (double)b.dur;
    std::vector<bool> fixed(n, false);
    // iterative: pin tiny segments to minW, distribute the rest proportionally
    for (int pass = 0; pass < 4; pass++) {
        double freeDur = 0; float freeW = avail;
        for (int i = 0; i < n; i++) { if (fixed[i]) freeW -= minW; else freeDur += (double)v[i].dur; }
        bool changed = false;
        for (int i = 0; i < n; i++) {
            if (fixed[i]) { ws[i] = minW; continue; }
            ws[i] = (float)(freeW * v[i].dur / max(1.0, freeDur));
            if (ws[i] < minW) { fixed[i] = true; changed = true; }
        }
        if (!changed) break;
    }
    float cx = x;
    for (int i = 0; i < n; i++) { xs[i] = cx; cx += ws[i] + gap; }
    (void)tot;
}

static void Hatch(Graphics& g, float x, float y, float w, float h, float r, const Color& base, const Color& stripe) {
    GraphicsPath p; RR(p, x, y, w, h, r);
    SolidBrush b(base); g.FillPath(&b, &p);
    Region old; g.GetClip(&old);
    g.SetClip(&p, CombineModeIntersect);
    Pen sp(stripe, 2.2f);
    for (float sx = x - h; sx < x + w + h; sx += 6.5f) g.DrawLine(&sp, sx, y + h, sx + h, y);
    g.SetClip(&old);
}

static void DrawBar(Graphics& g, float x, float y, float w, float h, bool big) {
    float pad = big ? 4.f : 0.f, gap = big ? 3.f : 2.f;
    if (big) {
        SolidBrush cb(Hex(0x0E2347)); FillRR(g, cb, x, y, w, h, 13);
        Pen cp(Hex(0x2A64C4, 200), 1.2f); StrokeRR(g, cp, x + 0.6f, y + 0.6f, w - 1.2f, h - 1.2f, 12.5f);
    }
    std::vector<float> xs, ws;
    LayoutSegs(A.blocks, x + pad, w - 2 * pad, gap, xs, ws);
    float sy = y + pad, sh = h - 2 * pad;
    for (int i = 0; i < (int)A.blocks.size(); i++) {
        const Block& b = A.blocks[i];
        float r = min(big ? 8.f : 4.f, ws[i] / 2);
        bool cur = i == A.idx;
        if (i < A.idx) {
            SegColors c = SegDone(b.kind);
            SolidBrush f(c.fill); FillRR(g, f, xs[i], sy, ws[i], sh, r);
            Pen bp(c.border, 1); StrokeRR(g, bp, xs[i] + .5f, sy + .5f, ws[i] - 1, sh - 1, r);
        } else if (cur) {
            bool fb = b.kind == K_FOCUS;
            Color base = fb ? Hex(0x2563C8) : Hex(0x1C7E9E);
            Color stripe = fb ? Hex(0x3A86F5) : Hex(0x33AACD);
            Color solid = fb ? Hex(0x2F7DF2) : Hex(0x27A0C6);
            Hatch(g, xs[i], sy, ws[i], sh, r, base, stripe);
            float p = (float)min(1.0, (double)b.elapsed / max(1LL, b.dur));
            if (p > 0) {
                GraphicsPath sp; RR(sp, xs[i], sy, ws[i], sh, r);
                Region old; g.GetClip(&old);
                g.SetClip(&sp, CombineModeIntersect);
                g.SetClip(RectF(xs[i], sy, ws[i] * p, sh), CombineModeIntersect);
                SolidBrush sb(solid); g.FillRectangle(&sb, xs[i], sy, ws[i], sh);
                g.SetClip(&old);
            }
            Pen bp(Color(120, 255, 255, 255), 1); StrokeRR(g, bp, xs[i] + .5f, sy + .5f, ws[i] - 1, sh - 1, r);
        } else {
            SegColors c = SegFuture(b.kind);
            SolidBrush f(c.fill); FillRR(g, f, xs[i], sy, ws[i], sh, r);
            Pen bp(c.border, 1); StrokeRR(g, bp, xs[i] + .5f, sy + .5f, ws[i] - 1, sh - 1, r);
        }
    }
    if (big && !Complete()) {
        const Block& b = A.blocks[A.idx];
        float p = (float)min(1.0, (double)b.elapsed / max(1LL, b.dur));
        float px = xs[A.idx] + ws[A.idx] * p;
        px = std::clamp(px, x + 3.f, x + w - 3.f);
        Pen ph(Color(255, 255, 255, 255), 2.f);
        g.DrawLine(&ph, px, y - 4, px, y + h - 3);

        // callout pill
        std::wstring label = b.kind == K_FOCUS ? L"Focus" : b.kind == K_LONG ? L"Long break" : L"Break";
        wchar_t num[8]; swprintf(num, 8, L"%d", b.round);
        float tw = TextW(label, 1, 14);
        float pw = 10 + 17 + 6 + tw + 12, phh = 25;
        float pcx = std::clamp(px, x + pw / 2, x + w - pw / 2);
        float pxl = pcx - pw / 2, pyt = y - 34;
        SolidBrush pb(P::blue);
        GraphicsPath pill; RR(pill, pxl, pyt, pw, phh, 9);
        g.FillPath(&pb, &pill);
        float tx = std::clamp(px, pxl + 10, pxl + pw - 10);
        PointF tri[3] = {{tx - 6, pyt + phh - 0.5f}, {tx + 6, pyt + phh - 0.5f}, {tx, pyt + phh + 6}};
        g.FillPolygon(&pb, tri, 3);
        SolidBrush wb(P::text);
        float ncx = pxl + 10 + 8.5f, ncy = pyt + phh / 2;
        g.FillEllipse(&wb, ncx - 8.5f, ncy - 8.5f, 17.f, 17.f);
        Text(g, num, 0, 11, ncx, ncy + 4, P::blue, AL_C);
        Text(g, label, 1, 14, ncx + 8.5f + 6, ncy + 5, P::text);
    }
}

static void CircleButton(Graphics& g, int id, float cx, float cy, float r, int icon, float iconSize) {
    bool hot = A.hover == id;
    SolidBrush b(hot ? P::circleHot : P::circle);
    g.FillEllipse(&b, cx - r, cy - r, 2 * r, 2 * r);
    if (icon == 2) { // ring for "done" state
        Pen rp(Color(120, 0x3D, 0x8B, 0xFF), 1.5f);
        g.DrawEllipse(&rp, cx - r + 1, cy - r + 1, 2 * r - 2, 2 * r - 2);
    }
    Icon(g, icon, cx + (icon == 0 ? iconSize * 0.05f : 0), cy, iconSize, P::circleIcon);
    AddZone(id, cx - r, cy - r, 2 * r, 2 * r);
}

static int MainIcon() {
    if (Complete()) return 3;
    if (Over()) return 2;
    return A.running ? 1 : 0;
}

static void IconButton(Graphics& g, int id, int icon, float cx, float cy) {
    bool hot = A.hover == id;
    if (hot) { SolidBrush b(P::chipHot); FillRR(g, b, cx - 11, cy - 11, 22, 22, 7); }
    Icon(g, icon, cx, cy, 12, hot ? P::text : P::sub);
    AddZone(id, cx - 11, cy - 11, 22, 22);
}

static void DrawMain(Graphics& g, float W, float H) {
    DrawCard(g, W, H, 28);
    Block* b = Cur();
    std::wstring big, sub;
    Color bigC = P::text;
    if (!b) {
        big = Clock(FocusedMs(), false);
        sub = L"focused · session complete";
    } else if (b->elapsed >= b->dur) {
        big = L"+" + Clock(b->elapsed - b->dur, false);
        bigC = P::blueText;
        sub = b->kind == K_FOCUS ? L"Time's up · extra focus" : L"Break's over · extra break";
    } else {
        big = Clock(b->dur - b->elapsed, true);
        const wchar_t* what = b->kind == K_FOCUS ? L"focus" : b->kind == K_LONG ? L"long break" : L"break";
        if (!A.started) {
            wchar_t s[96]; swprintf(s, 96, L"Ready · %d × %d min focus", A.cfg.rounds, A.cfg.focus);
            sub = s;
        } else if (!A.running) { sub = std::wstring(L"Paused · ") + what; bigC = WithA(P::text, 150); }
        else sub = std::wstring(L"Left for ") + what;
    }
    float bigSize = 48;
    while (bigSize > 30 && TextW(big, 0, bigSize) > W - 20 - 70) bigSize -= 2;
    Text(g, big, 0, bigSize, 19, 64, bigC);
    Text(g, sub, 2, 14, 20, 88, P::sub);
    CircleButton(g, Z_MAIN, W - 20 - 21, 44, 21, MainIcon(), 17);

    DrawBar(g, 20, 134, W - 40, 44, true);

    // stats row
    float by = 204;
    std::wstring f = StatClock(FocusedMs()), e = L"+" + StatClock(ExtraMs());
    float x = 20;
    x += Text(g, L"Focused", 2, 12, x, by, P::dim) + 5;
    x += Text(g, f, 1, 12, x, by, P::soft) + 14;
    if (A.inside) {
        float ix = W - 20 - 9;
        IconButton(g, Z_CLOSE, 8, ix, by - 4); ix -= 24;
        IconButton(g, Z_COMPACT, 7, ix, by - 4); ix -= 24;
        IconButton(g, Z_SETUP, 5, ix, by - 4); ix -= 24;
        IconButton(g, Z_RESET, 6, ix, by - 4); ix -= 24;
        if (!Complete()) IconButton(g, Z_SKIP, 4, ix, by - 4);
    } else {
        x += Text(g, L"Extra", 2, 12, x, by, P::dim) + 5;
        Text(g, e, 1, 12, x, by, ExtraMs() > 0 ? P::blueText : P::soft);
        wchar_t r[48];
        int total = A.cfg.rounds;
        if (Complete()) swprintf(r, 48, L"%d/%d rounds", RoundsDone(), total);
        else swprintf(r, 48, L"Round %d/%d", A.blocks[A.idx].round, total);
        Text(g, r, 2, 12, W - 20, by, P::dim, AL_R);
    }
    DrawBlink(g, W, H, 28);
}

static void DrawCompact(Graphics& g, float W, float H) {
    DrawCard(g, W, H, H / 2);
    CircleButton(g, Z_MAIN, 28, H / 2, 18, MainIcon(), 14);
    Block* b = Cur();
    std::wstring big; Color c = P::text; std::wstring lab;
    if (!b) { big = Clock(FocusedMs(), false); lab = L"Done"; }
    else if (b->elapsed >= b->dur) { big = L"+" + Clock(b->elapsed - b->dur, false); c = P::blueText; }
    else { big = Clock(b->dur - b->elapsed, true); if (A.started && !A.running) c = WithA(P::text, 150); }
    if (b) {
        wchar_t s[32];
        swprintf(s, 32, L"%ls %d/%d", b->kind == K_FOCUS ? L"Focus" : L"Break", b->round, A.cfg.rounds);
        lab = s;
    }
    Text(g, big, 0, 25, 55, 36, c);
    if (A.inside) IconButton(g, Z_COMPACT, 9, W - 24, H / 2);
    else Text(g, lab, 2, 11.5f, W - 18, 32, P::sub, AL_R);
    // thin progress line along the bottom
    float px = 56, pw = W - 56 - 22, py = H - 9;
    SolidBrush tb(Hex(0x1F2A40)); FillRR(g, tb, px, py, pw, 3, 1.5f);
    double prog = 0;
    if (b) prog = min(1.0, (double)b->elapsed / max(1LL, b->dur)); else prog = 1;
    if (prog > 0) {
        SolidBrush fb(b && b->kind != K_FOCUS ? Hex(0x27A0C6) : P::blue);
        FillRR(g, fb, px, py, (float)(pw * prog), 3, 1.5f);
    }
    DrawBlink(g, W, H, H / 2);
}

struct Row { const wchar_t* label; int* val; int lo, hi; };
static Row Rows(int i) {
    Cfg& e = A.edit;
    switch (i) {
    case 0: return {L"Focus", &e.focus, 1, 180};
    case 1: return {L"Break", &e.brk, 1, 60};
    case 2: return {L"Rounds", &e.rounds, 1, 12};
    case 3: return {L"Long break", &e.longBrk, 1, 90};
    default: return {L"Long break every", &e.longEvery, 0, 12};
    }
}
static std::wstring RowValue(int i) {
    int v = *Rows(i).val; wchar_t b[32];
    if (i == 2) swprintf(b, 32, L"%d", v);
    else if (i == 4) { if (v == 0) return L"off"; swprintf(b, 32, L"%d rounds", v); if (v == 1) return L"1 round"; }
    else swprintf(b, 32, L"%d min", v);
    return b;
}

static void Toggle(Graphics& g, int id, float x, float cy, bool on) {
    float w = 38, h = 22;
    bool hot = A.hover == id;
    SolidBrush tb(on ? (hot ? Hex(0x4A9CFF) : P::blue) : (hot ? Hex(0x34405A) : Hex(0x2A3346)));
    FillRR(g, tb, x, cy - h / 2, w, h, h / 2);
    SolidBrush kb(on ? P::text : P::sub);
    float kx = on ? x + w - h + 3 : x + 3;
    g.FillEllipse(&kb, kx, cy - h / 2 + 3, h - 6, h - 6);
}

static void DrawSetup(Graphics& g, float W, float H) {
    DrawCard(g, W, H, 26);
    Text(g, L"New session", 1, 18, 20, 40, P::text);
    Text(g, L"Focus blocks with breaks in between", 2, 12, 20, 58, P::sub);
    for (int i = 0; i < 5; i++) {
        float cy = 90 + i * 36.f;
        Row r = Rows(i);
        bool disabled = (i >= 3 && A.edit.longEvery == 0 && i == 3);
        Text(g, r.label, 2, 14, 20, cy + 5, disabled ? P::dim : P::soft);
        int dz = Z_DEC0 + i, iz = Z_INC0 + i;
        float dx = 166, ix = W - 32;
        SolidBrush d(A.hover == dz ? P::chipHot : P::chip), in(A.hover == iz ? P::chipHot : P::chip);
        g.FillEllipse(&d, dx - 13, cy - 13, 26.f, 26.f);
        g.FillEllipse(&in, ix - 13, cy - 13, 26.f, 26.f);
        Icon(g, 10, dx, cy, 12, *r.val > r.lo ? P::text : P::dim);
        Icon(g, 11, ix, cy, 12, *r.val < r.hi ? P::text : P::dim);
        AddZone(dz, dx - 14, cy - 14, 28, 28);
        AddZone(iz, ix - 14, cy - 14, 28, 28);
        std::wstring v = RowValue(i);
        float fs = 14;
        while (fs > 10 && TextW(v, 1, fs) > (ix - dx - 30)) fs -= 0.5f;
        Text(g, v, 1, fs, (dx + ix) / 2, cy + 5, disabled ? P::dim : P::text, AL_C);
    }
    const wchar_t* tl[2] = {L"Auto-continue to next block", L"Open Windows Focus on start"};
    bool tv[2] = {A.edit.autoCont, A.edit.winFocus};
    for (int i = 0; i < 2; i++) {
        float cy = 272 + i * 32.f;
        Text(g, tl[i], 2, 13.5f, 20, cy + 5, P::soft);
        Toggle(g, Z_TOG0 + i, W - 20 - 38, cy, tv[i]);
        AddZone(Z_TOG0 + i, 14, cy - 15, W - 28, 30);
    }
    // plan preview
    std::vector<Block> saved = A.blocks; int savedIdx = A.idx;
    A.blocks = BuildPlan(A.edit); A.idx = -1;
    DrawBar(g, 20, 324, W - 40, 12, false);
    long long total = 0, foc = 0;
    for (auto& b : A.blocks) { total += b.dur / 60000; if (b.kind == K_FOCUS) foc += b.dur / 60000; }
    A.blocks.swap(saved); A.idx = savedIdx;
    std::wstring tt = L"Total " + ShortDur(total) + L" · " + ShortDur(foc) + L" focus";
    Text(g, tt, 2, 12, 20, 356, P::sub);

    // buttons
    float by = 372, bh = 36;
    SolidBrush cb(A.hover == Z_CANCEL ? P::chipHot : P::chip);
    FillRR(g, cb, 20, by, 92, bh, 12);
    Text(g, L"Cancel", 1, 14, 20 + 46, by + bh / 2 + 5, P::soft, AL_C);
    AddZone(Z_CANCEL, 20, by, 92, bh);
    SolidBrush sb(A.hover == Z_START ? Hex(0x4A9CFF) : P::blue);
    FillRR(g, sb, 120, by, W - 140, bh, 12);
    Text(g, L"Start session", 1, 14, 120 + (W - 140) / 2, by + bh / 2 + 5, P::text, AL_C);
    AddZone(Z_START, 120, by, W - 140, bh);
    DrawBlink(g, W, H, 26);
}

static void CardSize(View v, float& w, float& h) {
    if (v == V_COMPACT) { w = 206; h = 56; }
    else if (v == V_SETUP) { w = 280; h = 428; }
    else { w = 280; h = 220; }
}

static void ClampToWork(int& x, int& y, int w, int h) {
    RECT wr{x, y, x + w, y + h};
    HMONITOR m = MonitorFromRect(&wr, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi{sizeof(mi)}; GetMonitorInfoW(m, &mi);
    RECT a = mi.rcWork;
    int s = (int)(SH * A.scale);
    x = std::clamp(x, (int)a.left - s, max((int)a.left - s, (int)a.right - w + s));
    y = std::clamp(y, (int)a.top - s, max((int)a.top - s, (int)a.bottom - h + s));
}

static void Render() {
    if (!A.hwnd) return;
    float cw, ch; CardSize(A.view, cw, ch);
    int W = (int)ceilf((cw + 2 * SH) * A.scale), H = (int)ceilf((ch + 2 * SH) * A.scale);

    BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = W; bi.bmiHeader.biHeight = -H; bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    HDC screen = GetDC(nullptr);
    HDC mem = CreateCompatibleDC(screen);
    HBITMAP dib = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!dib) { DeleteDC(mem); ReleaseDC(nullptr, screen); return; }
    HGDIOBJ old = SelectObject(mem, dib);
    memset(bits, 0, (size_t)W * H * 4);
    {
        Bitmap bmp(W, H, W * 4, PixelFormat32bppPARGB, (BYTE*)bits);
        Graphics g(&bmp);
        g.SetSmoothingMode(SmoothingModeAntiAlias);
        g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
        g.SetCompositingQuality(CompositingQualityHighQuality);
        g.ScaleTransform(A.scale, A.scale);
        g.TranslateTransform(SH, SH);
        A.zones.clear();
        if (A.view == V_MAIN) DrawMain(g, cw, ch);
        else if (A.view == V_COMPACT) DrawCompact(g, cw, ch);
        else DrawSetup(g, cw, ch);
    }
    RECT wr; GetWindowRect(A.hwnd, &wr);
    POINT pos{wr.left, wr.top}, src{0, 0};
    SIZE sz{W, H};
    BLENDFUNCTION bf{AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    UpdateLayeredWindow(A.hwnd, screen, &pos, &sz, mem, &src, 0, &bf, ULW_ALPHA);
    SelectObject(mem, old); DeleteObject(dib); DeleteDC(mem); ReleaseDC(nullptr, screen);
}

static void SetView(View v) {
    float ow, oh, nw, nh; CardSize(A.view, ow, oh); CardSize(v, nw, nh);
    A.view = v; A.hover = Z_NONE;
    RECT wr; GetWindowRect(A.hwnd, &wr);
    int W = (int)ceilf((nw + 2 * SH) * A.scale), H = (int)ceilf((nh + 2 * SH) * A.scale);
    int x = wr.left, y = wr.top;
    ClampToWork(x, y, W, H);
    SetWindowPos(A.hwnd, nullptr, x, y, W, H, SWP_NOZORDER | SWP_NOACTIVATE);
    Render();
}

// ---------------------------------------------------------------- tray & menu
static void UpdateTray() {
    Block* b = Cur();
    std::wstring t = L"Stint — ";
    if (!b) t += L"session complete";
    else if (b->elapsed >= b->dur) t += L"+" + Clock(b->elapsed - b->dur, false) + L" extra";
    else t += Clock(b->dur - b->elapsed, true) + (b->kind == K_FOCUS ? L" focus" : L" break") + (A.running ? L"" : L" (paused)");
    wcsncpy(A.nid.szTip, t.c_str(), 127); A.nid.szTip[127] = 0;
    A.nid.uFlags = NIF_TIP;
    Shell_NotifyIconW(NIM_MODIFY, &A.nid);
}
static void AddTray() {
    A.nid = {};
    A.nid.cbSize = sizeof(A.nid);
    A.nid.hWnd = A.hwnd; A.nid.uID = 1;
    A.nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    A.nid.uCallbackMessage = WM_TRAY;
    A.nid.hIcon = (HICON)LoadImageW(A.inst, MAKEINTRESOURCEW(1), IMAGE_ICON,
                                    GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
    wcscpy(A.nid.szTip, L"Stint");
    Shell_NotifyIconW(NIM_ADD, &A.nid);
}

static void ShowMenu() {
    HMENU m = CreatePopupMenu();
    bool comp = Complete();
    AppendMenuW(m, MF_STRING | (comp ? MF_GRAYED : 0), M_TOGGLE, A.running ? L"Pause" : (A.started ? L"Resume" : L"Start"));
    AppendMenuW(m, MF_STRING | (comp ? MF_GRAYED : 0), M_SKIP, Over() ? L"Finish block  ✓" : L"Skip to next block");
    AppendMenuW(m, MF_STRING, M_RESET, L"Restart session");
    AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(m, MF_STRING, M_SETUP, L"New session…");
    AppendMenuW(m, MF_STRING | (A.view == V_COMPACT ? MF_CHECKED : 0), M_COMPACT, L"Compact view");
    AppendMenuW(m, MF_STRING | (A.topmost ? MF_CHECKED : 0), M_TOP, L"Always on top");
    AppendMenuW(m, MF_STRING, M_WINFOCUS, L"Open Windows Focus");
    AppendMenuW(m, MF_STRING, M_SHOWHIDE, A.hidden ? L"Show widget" : L"Hide widget");
    AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(m, MF_STRING, M_EXIT, L"Exit");
    POINT pt; GetCursorPos(&pt);
    SetForegroundWindow(A.hwnd);
    TrackPopupMenu(m, TPM_RIGHTBUTTON, pt.x, pt.y, 0, A.hwnd, nullptr);
    PostMessageW(A.hwnd, WM_NULL, 0, 0);
    DestroyMenu(m);
}

static void OpenSetup() {
    if (A.view == V_SETUP) return;
    A.backView = A.view;
    A.edit = A.cfg;
    SetView(V_SETUP);
}

static void ApplyTopmost() {
    SetWindowPos(A.hwnd, A.topmost ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

static void DoAction(int id) {
    switch (id) {
    case Z_MAIN:
        if (Complete()) ResetSession(false);
        else if (Over()) Advance();
        else SetRunning(!A.running);
        break;
    case Z_SKIP: Advance(); break;
    case Z_RESET: ResetSession(false); break;
    case Z_SETUP: OpenSetup(); return;
    case Z_COMPACT:
        A.prefCompact = A.view != V_COMPACT;
        SetView(A.prefCompact ? V_COMPACT : V_MAIN); SaveSettings(); return;
    case Z_CLOSE: SaveSettings(); DestroyWindow(A.hwnd); return;
    case Z_TOG0: A.edit.autoCont = !A.edit.autoCont; break;
    case Z_TOG0 + 1: A.edit.winFocus = !A.edit.winFocus; break;
    case Z_CANCEL: SetView(A.backView == V_SETUP ? V_MAIN : A.backView); return;
    case Z_START:
        A.cfg = A.edit; ResetSession(true); SaveSettings();
        SetView(A.prefCompact ? V_COMPACT : V_MAIN); UpdateTray(); return;
    default:
        if (id >= Z_DEC0 && id < Z_DEC0 + 5) { Row r = Rows(id - Z_DEC0); *r.val = max(r.lo, *r.val - 1); }
        else if (id >= Z_INC0 && id < Z_INC0 + 5) { Row r = Rows(id - Z_INC0); *r.val = min(r.hi, *r.val + 1); }
        break;
    }
    Render(); UpdateTray();
}

static int HitZone(int px, int py) {
    float lx = px / A.scale - SH, ly = py / A.scale - SH;
    for (auto it = A.zones.rbegin(); it != A.zones.rend(); ++it)
        if (it->r.Contains(lx, ly)) return it->id;
    return Z_NONE;
}
static bool IsStepper(int id) { return (id >= Z_DEC0 && id < Z_DEC0 + 5) || (id >= Z_INC0 && id < Z_INC0 + 5); }

// ---------------------------------------------------------------- window proc
static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == A.taskbarCreated && A.taskbarCreated) { AddTray(); return 0; }
    switch (msg) {
    case WM_TIMER:
        if (wp == T_TICK) {
            Tick();
            long long sec = 0;
            if (Block* b = Cur()) sec = b->elapsed / 1000 + A.idx * 100000LL; else sec = -2;
            if (sec != A.lastShownSec) { A.lastShownSec = sec; if (!A.blinking) Render(); UpdateTray(); }
        } else if (wp == T_ANIM) {
            if (Now() - A.blinkStart > 960) { A.blinking = false; KillTimer(h, T_ANIM); }
            Render();
        } else if (wp == T_REPEAT) {
            if (A.repeatZone != Z_NONE && A.pressed == A.repeatZone && A.hover == A.repeatZone) {
                DoAction(A.repeatZone);
                if (++A.repeatCount == 1) SetTimer(h, T_REPEAT, 70, nullptr);
            } else KillTimer(h, T_REPEAT);
        } else if (wp == T_TOPMOST) {
            if (A.topmost && !A.dragging) ApplyTopmost();
        }
        return 0;

    case WM_MOUSEMOVE: {
        int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
        if (!A.tracking) {
            TRACKMOUSEEVENT t{sizeof(t), TME_LEAVE, h, 0}; TrackMouseEvent(&t); A.tracking = true;
        }
        if (A.dragging) {
            POINT c; GetCursorPos(&c);
            int dx = c.x - A.dragStart.x, dy = c.y - A.dragStart.y;
            if (abs(dx) > 2 || abs(dy) > 2) A.dragMoved = true;
            SetWindowPos(h, nullptr, A.winStart.x + dx, A.winStart.y + dy, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
            return 0;
        }
        bool wasInside = A.inside;
        A.inside = true;
        int z = HitZone(x, y);
        if (z != A.hover || !wasInside) {
            A.hover = z;
            Render();
            z = HitZone(x, y);  // zones can change on first hover (icons appear)
            if (z != A.hover) { A.hover = z; Render(); }
        }
        SetCursor(LoadCursor(nullptr, A.hover != Z_NONE ? IDC_HAND : IDC_ARROW));
        return 0;
    }
    case WM_MOUSELEAVE:
        A.tracking = false;
        if (!A.dragging) { A.inside = false; A.hover = Z_NONE; Render(); }
        return 0;
    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT) { SetCursor(LoadCursor(nullptr, A.hover != Z_NONE ? IDC_HAND : IDC_ARROW)); return TRUE; }
        break;
    case WM_LBUTTONDOWN: {
        int z = HitZone(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
        A.pressed = z;
        SetCapture(h);
        if (z == Z_NONE) {
            A.dragging = true; A.dragMoved = false;
            GetCursorPos(&A.dragStart);
            RECT r; GetWindowRect(h, &r); A.winStart = {r.left, r.top};
        } else if (IsStepper(z)) {
            DoAction(z);
            A.repeatZone = z; A.repeatCount = 0;
            SetTimer(h, T_REPEAT, 380, nullptr);
        }
        return 0;
    }
    case WM_LBUTTONUP: {
        ReleaseCapture();
        if (A.dragging) {
            A.dragging = false;
            RECT r; GetWindowRect(h, &r);
            int x = r.left, y = r.top;
            ClampToWork(x, y, r.right - r.left, r.bottom - r.top);
            if (x != r.left || y != r.top) SetWindowPos(h, nullptr, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
            if (A.dragMoved) SaveSettings();
        } else {
            int z = HitZone(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
            if (z == A.pressed && z != Z_NONE && !IsStepper(z)) DoAction(z);
        }
        A.pressed = Z_NONE; A.repeatZone = Z_NONE; KillTimer(h, T_REPEAT);
        return 0;
    }
    case WM_LBUTTONDBLCLK: {
        int z = HitZone(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
        if (z == Z_NONE && A.view != V_SETUP) DoAction(Z_COMPACT);
        else if (IsStepper(z)) DoAction(z);
        return 0;
    }
    case WM_MOUSEWHEEL:
        if (A.view == V_SETUP) {
            POINT p{GET_X_LPARAM(lp), GET_Y_LPARAM(lp)}; ScreenToClient(h, &p);
            float ly = p.y / A.scale - SH;
            int row = (int)floorf((ly - 72) / 36.f);
            if (row >= 0 && row < 5) DoAction((GET_WHEEL_DELTA_WPARAM(wp) > 0 ? Z_INC0 : Z_DEC0) + row);
        }
        return 0;
    case WM_RBUTTONUP: ShowMenu(); return 0;
    case WM_TRAY:
        if (LOWORD(lp) == WM_RBUTTONUP || LOWORD(lp) == WM_CONTEXTMENU) ShowMenu();
        else if (LOWORD(lp) == WM_LBUTTONUP) {
            if (A.hidden) { A.hidden = false; ShowWindow(h, SW_SHOWNA); Render(); }
            ApplyTopmost();
        }
        return 0;
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case M_TOGGLE: SetRunning(!A.running); break;
        case M_SKIP: Advance(); break;
        case M_RESET: ResetSession(false); break;
        case M_SETUP: if (A.hidden) { A.hidden = false; ShowWindow(h, SW_SHOWNA); } OpenSetup(); return 0;
        case M_COMPACT: DoAction(Z_COMPACT); return 0;
        case M_TOP: A.topmost = !A.topmost; ApplyTopmost(); SaveSettings(); break;
        case M_WINFOCUS: OpenWindowsFocus(); break;
        case M_SHOWHIDE:
            A.hidden = !A.hidden; ShowWindow(h, A.hidden ? SW_HIDE : SW_SHOWNA);
            break;
        case M_EXIT: SaveSettings(); DestroyWindow(h); return 0;
        }
        Render(); UpdateTray();
        return 0;
    case WM_POWERBROADCAST:
        if (wp == PBT_APMSUSPEND && A.running) { Tick(); A.running = false; Render(); UpdateTray(); }
        return TRUE;
    case WM_DPICHANGED: {
        A.scale = HIWORD(wp) / 96.f;
        RECT* r = (RECT*)lp;
        float cw, ch; CardSize(A.view, cw, ch);
        SetWindowPos(h, nullptr, r->left, r->top, (int)ceilf((cw + 2 * SH) * A.scale), (int)ceilf((ch + 2 * SH) * A.scale),
                     SWP_NOZORDER | SWP_NOACTIVATE);
        Render();
        return 0;
    }
    case WM_DISPLAYCHANGE: Render(); return 0;
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_DESTROY:
        Shell_NotifyIconW(NIM_DELETE, &A.nid);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

// ---------------------------------------------------------------- startup
static void EnableDpi() {
    HMODULE u = GetModuleHandleW(L"user32.dll");
    typedef BOOL(WINAPI * Ctx)(HANDLE);
    if (auto f = (Ctx)GetProcAddress(u, "SetProcessDpiAwarenessContext")) {
        if (f((HANDLE)-4)) return;  // PER_MONITOR_AWARE_V2
    }
    SetProcessDPIAware();
}
static float WindowScale(HWND h) {
    HMODULE u = GetModuleHandleW(L"user32.dll");
    typedef UINT(WINAPI * Dpi)(HWND);
    if (auto f = (Dpi)GetProcAddress(u, "GetDpiForWindow")) { UINT d = f(h); if (d) return d / 96.f; }
    HDC dc = GetDC(nullptr); int d = GetDeviceCaps(dc, LOGPIXELSX); ReleaseDC(nullptr, dc);
    return d / 96.f;
}
static FontFamily* MakeFamily(const wchar_t* name, const wchar_t* fallback) {
    FontFamily* f = new FontFamily(name);
    if (f->GetLastStatus() == Ok && f->IsAvailable()) return f;
    delete f;
    if (fallback) {
        f = new FontFamily(fallback);
        if (f->GetLastStatus() == Ok && f->IsAvailable()) return f;
        delete f;
    }
    return FontFamily::GenericSansSerif()->Clone();
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, PWSTR, int) {
    HANDLE mtx = CreateMutexW(nullptr, TRUE, L"Local\\StintFloatingTimer.Single");
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        HWND other = FindWindowW(kClass, nullptr);
        if (other) { ShowWindow(other, SW_SHOWNA); SetWindowPos(other, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); }
        return 0;
    }
    EnableDpi();
    A.inst = inst;
    GdiplusStartupInput gsi; ULONG_PTR tok;
    GdiplusStartup(&tok, &gsi, nullptr);
    // Inter is embedded in the exe (resources 101-103), so nothing needs installing.
    static PrivateFontCollection* pfc = new PrivateFontCollection();  // lives for the whole run
    for (int id = 101; id <= 103; id++) {
        HRSRC r = FindResourceW(inst, MAKEINTRESOURCEW(id), RT_RCDATA);
        if (!r) continue;
        HGLOBAL hg = LoadResource(inst, r);
        void* data = hg ? LockResource(hg) : nullptr;
        if (data) pfc->AddMemoryFont(data, (INT)SizeofResource(inst, r));
    }
    auto embedded = [](const wchar_t* name) -> FontFamily* {
        FontFamily* f = new FontFamily(name, pfc);
        if (f->GetLastStatus() == Ok && f->IsStyleAvailable(FontStyleRegular)) return f;
        delete f; return nullptr;
    };
    A.fBold = embedded(L"StintInterTime");
    A.fSemi = embedded(L"StintInterSemi");
    A.fReg = embedded(L"StintInterBody");
    if (A.fBold && A.fSemi && A.fReg) {
        A.embeddedFonts = true;
    } else {  // fallback: Segoe UI
        delete A.fBold; delete A.fSemi; delete A.fReg;
        A.fBold = MakeFamily(L"Segoe UI", L"Arial");
        A.fReg = MakeFamily(L"Segoe UI", L"Arial");
        FontFamily* s = new FontFamily(L"Segoe UI Semibold");
        if (s->GetLastStatus() == Ok && s->IsAvailable()) A.fSemi = s;
        else { delete s; A.fSemi = MakeFamily(L"Segoe UI", L"Arial"); A.semiIsBold = true; }
    }

    LoadSettings();
    ResetSession(false);

    WNDCLASSEXW wc{sizeof(wc)};
    wc.style = CS_DBLCLKS;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
    wc.hIconSm = (HICON)LoadImageW(inst, MAKEINTRESOURCEW(1), IMAGE_ICON, 16, 16, 0);
    wc.lpszClassName = kClass;
    RegisterClassExW(&wc);

    A.view = A.prefCompact ? V_COMPACT : V_MAIN;
    A.hwnd = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | (A.topmost ? WS_EX_TOPMOST : 0),
                             kClass, kTitle, WS_POPUP, 0, 0, 10, 10, nullptr, nullptr, inst, nullptr);
    A.scale = WindowScale(A.hwnd);
    float cw, ch; CardSize(A.view, cw, ch);
    int W = (int)ceilf((cw + 2 * SH) * A.scale), H = (int)ceilf((ch + 2 * SH) * A.scale);
    int x, y;
    if (IniInt(L"hasPos", 0)) { x = IniInt(L"x", 0); y = IniInt(L"y", 0); }
    else {
        RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
        x = wa.right - W - 8; y = wa.top + 8;
    }
    SetWindowPos(A.hwnd, nullptr, x, y, W, H, SWP_NOZORDER | SWP_NOACTIVATE);
    // re-evaluate DPI for the monitor we actually landed on
    A.scale = WindowScale(A.hwnd);
    W = (int)ceilf((cw + 2 * SH) * A.scale); H = (int)ceilf((ch + 2 * SH) * A.scale);
    ClampToWork(x, y, W, H);
    SetWindowPos(A.hwnd, nullptr, x, y, W, H, SWP_NOZORDER | SWP_NOACTIVATE);

    Render();
    ShowWindow(A.hwnd, SW_SHOWNA);
    ApplyTopmost();
    A.taskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");
    AddTray();
    UpdateTray();
    SetTimer(A.hwnd, T_TICK, 200, nullptr);
    SetTimer(A.hwnd, T_TOPMOST, 2000, nullptr);

    MSG m;
    while (GetMessageW(&m, nullptr, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageW(&m); }

    delete A.fBold; delete A.fReg; delete A.fSemi;
    GdiplusShutdown(tok);
    if (mtx) { ReleaseMutex(mtx); CloseHandle(mtx); }
    return 0;
}

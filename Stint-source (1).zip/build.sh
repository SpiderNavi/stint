#!/bin/sh
set -e
cd "$(dirname "$0")"
x86_64-w64-mingw32-windres stint.rc -O coff -o stint_res.o
x86_64-w64-mingw32-g++ -std=c++17 -O2 -municode -mwindows -static -static-libgcc -static-libstdc++ \
  stint.cpp stint_res.o -o Stint.exe -lgdiplus -lshell32 -lgdi32 -luser32 -lole32
x86_64-w64-mingw32-strip Stint.exe
ls -la Stint.exe
